<div id="footer">
<p>
<?php _e('Design by'); ?> <a href="http://beccary.com" title="<?php _e('Theme designed by'); ?> Beccary">Beccary</a> <?php _e('and'); ?> <a href="http://weblogs.us" title="<?php _e('Theme sponsored by'); ?> Weblogs.us">Weblogs.us</a>
&#183;
<a href="http://validator.w3.org/check/referer" title="<?php _e('This page validates as XHTML 1.0 Transitional'); ?>"><?php _e('<abbr title="eXtensible HyperText Markup Language">XHTML</abbr>'); ?></a>
&#183;
<a href="http://jigsaw.w3.org/css-validator/check/referer" title="<?php _e('This page validates as CSS'); ?>"><?php _e('<abbr title="Cascading Style Sheets">CSS</abbr>'); ?></a>
</p>
</div>

</div>

<?php do_action('wp_footer'); ?>

</body>
</html>
