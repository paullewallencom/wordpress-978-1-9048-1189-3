	</div>
		<div class="separator">
		</div>	
	<div id="footer">
	sample theme for wordpress book. powered by wordpress. 
	</div>
</div>

</body>
</html>